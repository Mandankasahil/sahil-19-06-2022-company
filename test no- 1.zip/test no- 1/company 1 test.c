#include <stdio.h>
#include <conio.h>

main() {
  int i, j;

  int arr[50][50] = {
                        {1, 0, 1},
                        {0, 0, 0},
                        {0, 1, 0}
                    };

 for(i=0; i<3; i++)
 {
     for(j=0; j<3; j++)
     {
            printf("%d ", arr[i][j]);
     }
     printf("\n");
 }

getch();
  return 0;
}
